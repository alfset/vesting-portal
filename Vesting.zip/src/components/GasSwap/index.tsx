import React from 'react'
import AppBody from '../../pages/AppBody'
import CrossChainEVM from './crossChainEVM'

const Index = () => {
  return (
    <AppBody>
      <CrossChainEVM />
    </AppBody>
  )
}

export default Index
